
USE WideWorldImporters
GO
/*
drop INDEX IDX_NC_Invoices_CustomerID_InvoiceDate ON [WideWorldImporters].[Sales].[Invoices]  
drop INDEX IDX_NC_Invoices_InvoiceDate ON [WideWorldImporters].[Sales].[Invoices] 
*/
--show the execution plan
--Run this a few times
----------------

set statistics io on 
set statistics time on 

SELECT 
    i.InvoiceDate , c.CustomerName
from [Sales].[Invoices] i
inner join sales.Customers c
on i.CustomerID = c.CustomerID
where i.InvoiceDate >= '1/1/2013' and i.InvoiceDate < '2/1/2013'

set statistics io off
set statistics time off 


go


/*


--before
Table 'Customers'. Scan count 9, logical reads 16, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Invoices'. Scan count 9, logical reads 8602, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Workfile'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.


--after
Table 'Workfile'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Invoices'. Scan count 1, logical reads 6, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
Table 'Customers'. Scan count 1, logical reads 7, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.



*/
