use w
go

--RUN ENTIRE SCRIPT
if exists (select * from information_schema.TABLES where table_name = 'fragemall')
DROP TABLE dbo.fragemall
go
CREATE TABLE dbo.fragemall
	(
	fragid uniqueidentifier NOT NULL,
	fragtext varchar(4000) NOT NULL
	)  
GO
ALTER TABLE dbo.fragemall ADD CONSTRAINT
	PK_fragemall PRIMARY KEY CLUSTERED 
	(
	fragid
	) WITH(FILLFACTOR =100)
go
CREATE NONCLUSTERED INDEX IDX_NC_fragemall
ON dbo.fragemall (FRAGTEXT) WITH(FILLFACTOR =100)
GO


--Insert roughly 131072k records

	insert into dbo.fragemall (fragid, fragtext) 
	select newid(), replicate(char(round(rand()*100,0)),round(rand()*100,0))
go
declare @x integer
set @x = 1 
while @x < 20
begin
	insert into dbo.fragemall (fragid, fragtext) 
	select newid(), replicate(char(round(rand()*100,0)),round(rand()*100,0))
	from fragemall
set @x = @x + 1
end
go
select count(1) from dbo.fragemall




