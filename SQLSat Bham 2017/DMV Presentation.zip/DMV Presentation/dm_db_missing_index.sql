

use adventureworks
go


----------------

SELECT 
    *
FROM Sales.SalesOrderDetail
inner join 
Sales.SalesOrderHeader
on Sales.SalesOrderDetail.SalesOrderID = Sales.SalesOrderHeader.SalesOrderID
where UnitPrice < 200 and OrderQty > 1
go
SELECT 
    *
FROM Sales.SalesOrderDetail
inner join 
Sales.SalesOrderHeader
on Sales.SalesOrderDetail.SalesOrderID = Sales.SalesOrderHeader.SalesOrderID
where Status = 5 and ProductID = 776

go


drop index AK_SalesOrderDetail_rowguid on sales.salesorderdetail 
drop index IDX_NC_SalesOrderDetail_OrderQty_UnitPrice on sales.salesorderdetail 
drop index IDX_NC_SalesOrderDetail_ProductID on sales.salesorderdetail  
drop index PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID on sales.salesorderdetail 