--change to text mode
use securitydemo
go
select * from dbo.denyusertable
go
select * from dbo.denyusertableview
go
exec dbo.denyusertablesproc
go
exec dbo.denyusertablesproc_adhoc
go